using Microsoft.VisualBasic.Devices;
using System.IO;
using System.Linq;
using System.Text.Json;
using static System.Net.Mime.MediaTypeNames;
namespace Module7JsonStudentRecords
{
    public partial class dgvLINGQStudents : Form
    {
        private List<Student> students = new List<Student>();

        private void SaveJSON()
        {
            if (students.Count == 0)
            {
                lblStatus.Text = "There are no student records to save.";
                return;
            }
            string filePath = Path.Combine(System.Windows.Forms.Application.StartupPath, "students.json");
            string json = JsonSerializer.Serialize(students, new JsonSerializerOptions
            {
                WriteIndented = true
            });
            File.WriteAllText(filePath, json);
            lblStatus.Text = "Student records saved successfully!";
        }

        public void AddStudent()
        {
            int studentID = Int32.Parse(txtStudentID.Text);
            string firstName = txtFirstName.Text;
            string lastName = txtLastName.Text;
            string programName = txtProgram.Text;
            double gpa = Convert.ToDouble(nudGPA.Value);
            Student student = new Student
            {
                StudentId = studentID,
                FirstName = firstName,
                LastName = lastName,
                ProgramName = programName,
                GPA = gpa
            };
            students.Add(student);
            ClearDisplay();
            LoadPrograms();
            txtStudentID.Clear();
            txtFirstName.Clear();
            txtLastName.Clear();
            txtProgram.Clear();
            nudGPA.Value = 0;
            lblStatus.Text = "Student added successfully!";
        }

        private bool ValidateInput()
        {
            int studentID;
            if (!Int32.TryParse(txtStudentID.Text, out studentID) || studentID <= 0 || string.IsNullOrWhiteSpace(txtFirstName.Text) || string.IsNullOrWhiteSpace(txtLastName.Text) || nudGPA.Value < 0 || nudGPA.Value > 4.0m || string.IsNullOrWhiteSpace(txtProgram.Text))
            {
                lblStatus.Text = "Please fill in all fields correctly. " +
                    "Ensure the ID is a positive integer and the GPA is between 0 and 4.";

                return false;
            }
            return true;
        }

        private void ClearDisplay()
        {
            dgvStudents.DataSource = null;
            dgvStudents.DataSource = students;
        }

        private void LoadJSON()
        {
            string filePath = Path.Combine(System.Windows.Forms.Application.StartupPath, "students.json");
            if (!File.Exists(filePath))
            {
                lblStatus.Text = "The students.json file does not exist.";
                return;
            }
            try
            {
                string json = File.ReadAllText(filePath);
                if (string.IsNullOrWhiteSpace(json))
                {
                    lblStatus.Text = "The students.json file is empty.";
                    return;
                }
                List<Student> loadedStudents = JsonSerializer.Deserialize<List<Student>>(json);
                if (loadedStudents == null)
                {
                    lblStatus.Text = "The student data could not be loaded.";
                    return;
                }
                students = loadedStudents;
                ClearDisplay();
                LoadPrograms();
                lblStatus.Text = "Student records loaded successfully!";
            }
            catch (JsonException)
            {
                lblStatus.Text = "The JSON format is invalid.";
            }
            catch (IOException)
            {
                lblStatus.Text = "A file-processing error occurred.";
            }
            catch (Exception)
            {
                lblStatus.Text = "The student data could not be converted.";
            }
        }

        public dgvLINGQStudents()
        {
            InitializeComponent();
            nudGPA.Increment = 0.1m;
            nudGPA.DecimalPlaces = 1;
            nudGPA.Minimum = 0.0m;
            nudGPA.Maximum = 4.0m;
            nudLINQGPA.Increment = 0.1m;
            nudLINQGPA.DecimalPlaces = 1;
            nudLINQGPA.Minimum = 0.0m;
            nudLINQGPA.Maximum = 4.0m;
        }


        private void btnAddStudent_Click(object sender, EventArgs e)
        {
            if (ValidateInput())
            {
                AddStudent();
            }
        }

        private void btnSaveJSON_Click(object sender, EventArgs e)
        {
            SaveJSON();
        }

        private void btnLoadJSON_Click(object sender, EventArgs e)
        {
            LoadJSON();
        }

        private void btnClearDisplay_Click(object sender, EventArgs e)
        {
            dgvStudents.DataSource = null;
            lblStatus.Text = "Student display cleared.";
        }

        private void DisplayStudents(List<Student> records)
        {
            dgvLINQStudents.DataSource = null;
            dgvLINQStudents.DataSource = records;
        }

        private void btnShowAll_Click(object sender, EventArgs e)
        {
            ShowAllStudents();
        }

        private void SearchByProgram()
        {
            string selectedProgram = cboLINQProgram.Text;
            if (string.IsNullOrWhiteSpace(selectedProgram))
            {
                lblStatus.Text = "Please select a program.";
                return;
            }
            var results = students.Where(student => student.ProgramName == selectedProgram).ToList();
            DisplayStudents(results);
            if (results.Count == 0)
            {
                lblStatus.Text = "No students were found in that program.";
            }
            else
            {
                lblStatus.Text = results.Count + " student(s) found.";
            }
        }

        private void SearchByGPA()
        {
            double minimumGpa = Convert.ToDouble(nudLINQGPA.Value);
            if (minimumGpa < 0.0 || minimumGpa > 4.0)
            {
                lblStatus.Text = "Please enter a GPA between 0.0 and 4.0.";
                return;
            }
            var results = students.Where(student => student.GPA >= minimumGpa).ToList();
            DisplayStudents(results);
            if (results.Count == 0)
            {
                lblStatus.Text = "No students were found with a GPA of " +
                    minimumGpa.ToString("0.0") + " or higher.";
            }
            else
            {
                lblStatus.Text = results.Count + " student(s) found with a GPA of " +
                    minimumGpa.ToString("0.0") + " or higher.";
            }
        }

        private void SearchByIDOrName()
        {
            string searchText = txtLINGQSearch.Text.Trim();

            if (string.IsNullOrWhiteSpace(searchText))
            {
                lblStatus.Text = "Please enter a student ID or name.";
                return;
            }

            int studentID;

            if (Int32.TryParse(searchText, out studentID))
            {
                Student result = students.FirstOrDefault(student => student.StudentId == studentID);
                if (result == null)
                {
                    dgvLINQStudents.DataSource = null;
                    lblStatus.Text = "No student was found with that ID.";
                }
                else
                {
                    dgvLINQStudents.DataSource = new List<Student> { result };
                    lblStatus.Text = "Student found.";
                }
            }
            else
            {
                var results = students.Where(student => student.FirstName.Contains(searchText, StringComparison.OrdinalIgnoreCase) || student.LastName.Contains(searchText, StringComparison.OrdinalIgnoreCase)).ToList();
                DisplayStudents(results);
                if (results.Count == 0)
                {
                    lblStatus.Text = "No students were found with that name.";
                }
                else
                {
                    lblStatus.Text = results.Count + " student(s) found.";
                }
            }
        }

        private void SortStudents()
        {
            var results = students.OrderBy(student => student.LastName).ThenBy(student => student.FirstName).ToList();
            DisplayStudents(results);
            lblStatus.Text = "Students sorted by last name and first name.";
        }

        private void SortByGPA()
        {
            var results = students.OrderByDescending(student => student.GPA).ToList();
            DisplayStudents(results);
            Student topStudent = students.OrderByDescending(student => student.GPA).FirstOrDefault();
            if (topStudent == null)
            {
                lblStatus.Text = "There are no students to sort.";
            }
            else
            {
                lblStatus.Text = "Highest GPA: " + topStudent.FirstName + " " + topStudent.LastName + " (" + topStudent.GPA.ToString("0.0") + ")";
            }
        }

        private void SearchByProgramAndGPA()
        {
            string selectedProgram = cboLINQProgram.Text;
            double minimumGpa = Convert.ToDouble(nudLINQGPA.Value);
            if (string.IsNullOrWhiteSpace(selectedProgram))
            {
                lblStatus.Text = "Please select a program.";
                return;
            }
            if (minimumGpa < 0.0 || minimumGpa > 4.0)
            {
                lblStatus.Text = "Please enter a GPA between 0.0 and 4.0.";
                return;
            }
            var results = students.Where(student => student.ProgramName == selectedProgram && student.GPA >= minimumGpa).OrderByDescending(student => student.GPA).ToList();
            DisplayStudents(results);
            if (results.Count == 0)
            {
                lblStatus.Text = "No students were found in " + selectedProgram + " with a GPA of " + minimumGpa.ToString("0.0") + " or higher.";
            }
            else
            {
                lblStatus.Text = results.Count + " student(s) found.";
            }
        }

        private void ShowStudentSummary()
        {
            if (students.Count == 0)
            {
                lblStatus.Text = "No student records are available.";
                return;
            }
            int totalStudents = students.Count();
            double averageGpa = students.Average(student => student.GPA);
            double highestGpa = students.Max(student => student.GPA);
            double lowestGpa = students.Min(student => student.GPA);
            int studentsAbove3 = students.Count(student => student.GPA >= 3.0);
            lblStatus.Text = "Student Summary" + Environment.NewLine + "Total students: " + totalStudents + Environment.NewLine + "Average GPA: " + averageGpa.ToString("0.00") + Environment.NewLine + "Highest GPA: " + highestGpa.ToString("0.00") + Environment.NewLine + "Lowest GPA: " + lowestGpa.ToString("0.00") + Environment.NewLine + "Students with GPA 3.0 or higher: " + studentsAbove3;
        }

        private void ShowAllStudents()
        {
            if (students.Count == 0)
            {
                lblStatus.Text = "There are no student records to display.";
                return;
            }
            dgvLINQStudents.DataSource = null;
            dgvLINQStudents.DataSource = students;
            lblStatus.Text = students.Count + " student(s) displayed.";
        }

        private void FilterByProgram()
        {
            string selectedProgram = cboLINQProgram.Text;

            if (string.IsNullOrWhiteSpace(selectedProgram))
            {
                lblStatus.Text = "Please select a program.";
                return;
            }

            var results = students
                .Where(student => student.ProgramName == selectedProgram)
                .ToList();

            DisplayStudents(results);

            if (results.Count == 0)
            {
                lblStatus.Text = "No students were found in that program.";
            }
            else
            {
                lblStatus.Text = results.Count + " student(s) found.";
            }
        }

        private void FilterByGpa()
        {
            double minimumGpa = Convert.ToDouble(nudLINQGPA.Value);

            if (minimumGpa < 0.0 || minimumGpa > 4.0)
            {
                lblStatus.Text = "Please enter a GPA between 0.0 and 4.0.";
                return;
            }

            var results = students
                .Where(student => student.GPA >= minimumGpa)
                .ToList();

            DisplayStudents(results);

            if (results.Count == 0)
            {
                lblStatus.Text = "No students were found with a GPA of " +
                    minimumGpa.ToString("0.0") + " or higher.";
            }
            else
            {
                lblStatus.Text = results.Count + " student(s) found.";
            }
        }

        private void SearchStudents()
        {
            string searchText = txtLINGQSearch.Text.Trim();
            if (string.IsNullOrWhiteSpace(searchText))
            {
                lblStatus.Text = "Please enter a student ID or name.";
                return;
            }
            int studentID;
            if (Int32.TryParse(searchText, out studentID))
            {
                Student result = students.FirstOrDefault(student => student.StudentId == studentID);
                if (result == null)
                {
                    DisplayStudents(new List<Student>());
                    lblStatus.Text = "No student was found with that ID.";
                }
                else
                {
                    DisplayStudents(new List<Student> { result });
                    lblStatus.Text = "Student found.";
                }
            }
            else
            {
                var results = students.Where(student => student.FirstName.Contains(searchText, StringComparison.OrdinalIgnoreCase) || student.LastName.Contains(searchText, StringComparison.OrdinalIgnoreCase)).ToList();
                DisplayStudents(results);
                if (results.Count == 0)
                {
                    lblStatus.Text = "No students were found with that name.";
                }
                else
                {
                    lblStatus.Text = results.Count + " student(s) found.";
                }
            }
        }

        private void SortByName()
        {
            var results = students.OrderBy(student => student.LastName).ThenBy(student => student.FirstName).ToList();
            DisplayStudents(results);
            lblStatus.Text = "Students sorted by last name and first name.";
        }

        private void SortByGpa()
        {
            var results = students.OrderByDescending(student => student.GPA).ToList();
            DisplayStudents(results);
            Student topStudent = results.FirstOrDefault();
            if (topStudent == null)
            {
                lblStatus.Text = "There are no students to sort.";
            }
            else
            {
                lblStatus.Text = "Highest GPA: " + topStudent.FirstName + " " + topStudent.LastName + " (" + topStudent.GPA.ToString("0.0") + ")";
            }
        }

        private void RunCombinedQuery()
        {
            string selectedProgram = cboLINQProgram.Text;
            double minimumGpa = Convert.ToDouble(nudLINQGPA.Value);
            if (string.IsNullOrWhiteSpace(selectedProgram))
            {
                lblStatus.Text = "Please select a program.";
                return;
            }
            if (minimumGpa < 0.0 || minimumGpa > 4.0)
            {
                lblStatus.Text = "Please enter a GPA between 0.0 and 4.0.";
                return;
            }
            var results = students.Where(student => student.ProgramName == selectedProgram && student.GPA >= minimumGpa).OrderByDescending(student => student.GPA).ToList();
            DisplayStudents(results);
            if (results.Count == 0)
            {
                lblStatus.Text = "No students were found in " + selectedProgram + " with a GPA of " + minimumGpa.ToString("0.0") + " or higher.";
            }
            else
            {
                lblStatus.Text = results.Count + " student(s) found.";
            }
        }

        private void DisplaySummary()
        {
            if (students.Count == 0)
            {
                lblStatus.Text = "No student records are available.";
                return;
            }
            int totalStudents = students.Count();
            double averageGpa = students.Average(student => student.GPA);
            double highestGpa = students.Max(student => student.GPA);
            double lowestGpa = students.Min(student => student.GPA);
            int studentsAbove3 = students.Count(student => student.GPA >= 3.0);
            lblStatus.Text = "Student Summary" + Environment.NewLine + "Total students: " + totalStudents + Environment.NewLine + "Average GPA: " + averageGpa.ToString("0.00") + Environment.NewLine + "Highest GPA: " + highestGpa.ToString("0.00") + Environment.NewLine + "Lowest GPA: " + lowestGpa.ToString("0.00") + Environment.NewLine + "Students with GPA 3.0 or higher: " + studentsAbove3;
        }

        private void btnLINQDisplay_Click(object sender, EventArgs e)
        {
            DisplaySummary();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            SearchStudents();
        }

        private void btnSortName_Click(object sender, EventArgs e)
        {
            SortByName();
        }

        private void btnFilterProgram_Click(object sender, EventArgs e)
        {
            FilterByProgram();
        }

        private void btnSortGPA_Click_1(object sender, EventArgs e)
        {
            SortByGPA();
        }

        private void btnFilterGPA_Click(object sender, EventArgs e)
        {
            FilterByGpa();
        }

        private void cboLINQProgram_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void LoadPrograms()
        {
            cboLINQProgram.Items.Clear();
            var programs = students.Select(student => student.ProgramName).Distinct().OrderBy(program => program).ToList();
            foreach (string program in programs)
            {
                cboLINQProgram.Items.Add(program);
            }
        }
    }
}
