﻿namespace Module7JsonStudentRecords
{
    partial class dgvLINGQStudents
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtStudentID = new TextBox();
            txtFirstName = new TextBox();
            txtLastName = new TextBox();
            nudGPA = new NumericUpDown();
            btnAddStudent = new Button();
            btnClearDisplay = new Button();
            btnSaveJSON = new Button();
            btnLoadJSON = new Button();
            dgvStudents = new DataGridView();
            lblStatus = new Label();
            lblStudentID = new Label();
            lblFirstName = new Label();
            lblLastName = new Label();
            lblGPA = new Label();
            lblProgram = new Label();
            txtProgram = new TextBox();
            btnShowAll = new Button();
            btnFilterProgram = new Button();
            btnFilterGPA = new Button();
            btnSearch = new Button();
            btnSortName = new Button();
            btnSortGPA = new Button();
            txtLINGQSearch = new TextBox();
            nudLINQGPA = new NumericUpDown();
            cboLINQProgram = new ComboBox();
            btnLINQDisplay = new Button();
            dgvLINQStudents = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)nudGPA).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvStudents).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudLINQGPA).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvLINQStudents).BeginInit();
            SuspendLayout();
            // 
            // txtStudentID
            // 
            txtStudentID.Location = new Point(118, 32);
            txtStudentID.Name = "txtStudentID";
            txtStudentID.Size = new Size(77, 21);
            txtStudentID.TabIndex = 0;
            txtStudentID.Text = "Student ID";
            // 
            // txtFirstName
            // 
            txtFirstName.Location = new Point(118, 59);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(77, 21);
            txtFirstName.TabIndex = 1;
            txtFirstName.Text = "First Name";
            // 
            // txtLastName
            // 
            txtLastName.Location = new Point(118, 86);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(77, 21);
            txtLastName.TabIndex = 2;
            txtLastName.Text = "Last Name";
            // 
            // nudGPA
            // 
            nudGPA.DecimalPlaces = 1;
            nudGPA.Increment = new decimal(new int[] { 1, 0, 0, 65536 });
            nudGPA.Location = new Point(118, 140);
            nudGPA.Maximum = new decimal(new int[] { 40, 0, 0, 65536 });
            nudGPA.Name = "nudGPA";
            nudGPA.Size = new Size(77, 21);
            nudGPA.TabIndex = 3;
            // 
            // btnAddStudent
            // 
            btnAddStudent.Location = new Point(217, 67);
            btnAddStudent.Name = "btnAddStudent";
            btnAddStudent.Size = new Size(90, 40);
            btnAddStudent.TabIndex = 4;
            btnAddStudent.Text = "Add Student";
            btnAddStudent.UseVisualStyleBackColor = true;
            btnAddStudent.Click += btnAddStudent_Click;
            // 
            // btnClearDisplay
            // 
            btnClearDisplay.Location = new Point(586, 191);
            btnClearDisplay.Name = "btnClearDisplay";
            btnClearDisplay.Size = new Size(63, 58);
            btnClearDisplay.TabIndex = 5;
            btnClearDisplay.Text = "Clear Display";
            btnClearDisplay.UseVisualStyleBackColor = true;
            btnClearDisplay.Click += btnClearDisplay_Click;
            // 
            // btnSaveJSON
            // 
            btnSaveJSON.Location = new Point(368, 191);
            btnSaveJSON.Name = "btnSaveJSON";
            btnSaveJSON.Size = new Size(63, 58);
            btnSaveJSON.TabIndex = 6;
            btnSaveJSON.Text = "Save to JSON";
            btnSaveJSON.UseVisualStyleBackColor = true;
            btnSaveJSON.Click += btnSaveJSON_Click;
            // 
            // btnLoadJSON
            // 
            btnLoadJSON.Location = new Point(481, 191);
            btnLoadJSON.Name = "btnLoadJSON";
            btnLoadJSON.Size = new Size(63, 58);
            btnLoadJSON.TabIndex = 7;
            btnLoadJSON.Text = "Load from JSON";
            btnLoadJSON.UseVisualStyleBackColor = true;
            btnLoadJSON.Click += btnLoadJSON_Click;
            // 
            // dgvStudents
            // 
            dgvStudents.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvStudents.Location = new Point(326, 21);
            dgvStudents.Name = "dgvStudents";
            dgvStudents.Size = new Size(369, 150);
            dgvStudents.TabIndex = 8;
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(41, 176);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(122, 15);
            lblStatus.TabIndex = 9;
            lblStatus.Text = "Displays Errors Here";
            // 
            // lblStudentID
            // 
            lblStudentID.AutoSize = true;
            lblStudentID.Location = new Point(41, 38);
            lblStudentID.Name = "lblStudentID";
            lblStudentID.Size = new Size(67, 15);
            lblStudentID.TabIndex = 10;
            lblStudentID.Text = "Student ID:";
            // 
            // lblFirstName
            // 
            lblFirstName.AutoSize = true;
            lblFirstName.Location = new Point(41, 65);
            lblFirstName.Name = "lblFirstName";
            lblFirstName.Size = new Size(71, 15);
            lblFirstName.TabIndex = 11;
            lblFirstName.Text = "First Name:";
            // 
            // lblLastName
            // 
            lblLastName.AutoSize = true;
            lblLastName.Location = new Point(41, 92);
            lblLastName.Name = "lblLastName";
            lblLastName.Size = new Size(71, 15);
            lblLastName.TabIndex = 12;
            lblLastName.Text = "Last Name:";
            // 
            // lblGPA
            // 
            lblGPA.AutoSize = true;
            lblGPA.Location = new Point(41, 146);
            lblGPA.Name = "lblGPA";
            lblGPA.Size = new Size(33, 15);
            lblGPA.TabIndex = 13;
            lblGPA.Text = "GPA:";
            // 
            // lblProgram
            // 
            lblProgram.AutoSize = true;
            lblProgram.Location = new Point(41, 118);
            lblProgram.Name = "lblProgram";
            lblProgram.Size = new Size(95, 15);
            lblProgram.TabIndex = 14;
            lblProgram.Text = "Program Name:";
            // 
            // txtProgram
            // 
            txtProgram.Location = new Point(142, 113);
            txtProgram.Name = "txtProgram";
            txtProgram.Size = new Size(98, 21);
            txtProgram.TabIndex = 15;
            txtProgram.Text = "Program Name";
            // 
            // btnShowAll
            // 
            btnShowAll.Location = new Point(28, 386);
            btnShowAll.Name = "btnShowAll";
            btnShowAll.Size = new Size(89, 43);
            btnShowAll.TabIndex = 16;
            btnShowAll.Text = "Show All Students";
            btnShowAll.UseVisualStyleBackColor = true;
            btnShowAll.Click += btnShowAll_Click;
            // 
            // btnFilterProgram
            // 
            btnFilterProgram.Location = new Point(123, 386);
            btnFilterProgram.Name = "btnFilterProgram";
            btnFilterProgram.Size = new Size(89, 43);
            btnFilterProgram.TabIndex = 18;
            btnFilterProgram.Text = "Filter By Program";
            btnFilterProgram.UseVisualStyleBackColor = true;
            btnFilterProgram.Click += btnFilterProgram_Click;
            // 
            // btnFilterGPA
            // 
            btnFilterGPA.Location = new Point(218, 386);
            btnFilterGPA.Name = "btnFilterGPA";
            btnFilterGPA.Size = new Size(89, 43);
            btnFilterGPA.TabIndex = 19;
            btnFilterGPA.Text = "Filter By GPA";
            btnFilterGPA.UseVisualStyleBackColor = true;
            btnFilterGPA.Click += btnFilterGPA_Click;
            // 
            // btnSearch
            // 
            btnSearch.Location = new Point(28, 337);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(89, 43);
            btnSearch.TabIndex = 20;
            btnSearch.Text = "Search for Student";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // btnSortName
            // 
            btnSortName.Location = new Point(123, 337);
            btnSortName.Name = "btnSortName";
            btnSortName.Size = new Size(89, 43);
            btnSortName.TabIndex = 21;
            btnSortName.Text = "Sort By Last Name";
            btnSortName.UseVisualStyleBackColor = true;
            btnSortName.Click += btnSortName_Click;
            // 
            // btnSortGPA
            // 
            btnSortGPA.Location = new Point(217, 337);
            btnSortGPA.Name = "btnSortGPA";
            btnSortGPA.Size = new Size(89, 43);
            btnSortGPA.TabIndex = 22;
            btnSortGPA.Text = "Sort By GPA";
            btnSortGPA.UseVisualStyleBackColor = true;
            btnSortGPA.Click += btnSortGPA_Click_1;
            // 
            // txtLINGQSearch
            // 
            txtLINGQSearch.Location = new Point(23, 300);
            txtLINGQSearch.Name = "txtLINGQSearch";
            txtLINGQSearch.Size = new Size(77, 21);
            txtLINGQSearch.TabIndex = 24;
            txtLINGQSearch.Text = "Name/ID";
            // 
            // nudLINQGPA
            // 
            nudLINQGPA.DecimalPlaces = 1;
            nudLINQGPA.Increment = new decimal(new int[] { 1, 0, 0, 65536 });
            nudLINQGPA.Location = new Point(118, 300);
            nudLINQGPA.Maximum = new decimal(new int[] { 40, 0, 0, 65536 });
            nudLINQGPA.Name = "nudLINQGPA";
            nudLINQGPA.Size = new Size(77, 21);
            nudLINQGPA.TabIndex = 25;
            // 
            // cboLINQProgram
            // 
            cboLINQProgram.FormattingEnabled = true;
            cboLINQProgram.Location = new Point(23, 271);
            cboLINQProgram.Name = "cboLINQProgram";
            cboLINQProgram.Size = new Size(105, 23);
            cboLINQProgram.TabIndex = 26;
            cboLINQProgram.SelectedIndexChanged += cboLINQProgram_SelectedIndexChanged;
            // 
            // btnLINQDisplay
            // 
            btnLINQDisplay.Location = new Point(218, 288);
            btnLINQDisplay.Name = "btnLINQDisplay";
            btnLINQDisplay.Size = new Size(89, 43);
            btnLINQDisplay.TabIndex = 27;
            btnLINQDisplay.Text = "Display Summary";
            btnLINQDisplay.UseVisualStyleBackColor = true;
            btnLINQDisplay.Click += btnLINQDisplay_Click;
            // 
            // dgvLINQStudents
            // 
            dgvLINQStudents.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvLINQStudents.Location = new Point(326, 271);
            dgvLINQStudents.Name = "dgvLINQStudents";
            dgvLINQStudents.Size = new Size(369, 150);
            dgvLINQStudents.TabIndex = 28;
            // 
            // dgvLINGQStudents
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(dgvLINQStudents);
            Controls.Add(btnLINQDisplay);
            Controls.Add(cboLINQProgram);
            Controls.Add(nudLINQGPA);
            Controls.Add(txtLINGQSearch);
            Controls.Add(btnSortGPA);
            Controls.Add(btnSortName);
            Controls.Add(btnSearch);
            Controls.Add(btnFilterGPA);
            Controls.Add(btnFilterProgram);
            Controls.Add(btnShowAll);
            Controls.Add(txtProgram);
            Controls.Add(lblProgram);
            Controls.Add(lblGPA);
            Controls.Add(lblLastName);
            Controls.Add(lblFirstName);
            Controls.Add(lblStudentID);
            Controls.Add(lblStatus);
            Controls.Add(dgvStudents);
            Controls.Add(btnLoadJSON);
            Controls.Add(btnSaveJSON);
            Controls.Add(btnClearDisplay);
            Controls.Add(btnAddStudent);
            Controls.Add(nudGPA);
            Controls.Add(txtLastName);
            Controls.Add(txtFirstName);
            Controls.Add(txtStudentID);
            Name = "dgvLINGQStudents";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)nudGPA).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvStudents).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudLINQGPA).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvLINQStudents).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtStudentID;
        private TextBox txtFirstName;
        private TextBox txtLastName;
        private NumericUpDown nudGPA;
        private Button btnAddStudent;
        private Button btnClearDisplay;
        private Button btnSaveJSON;
        private Button btnLoadJSON;
        private DataGridView dgvStudents;
        private Label lblStatus;
        private Label lblStudentID;
        private Label lblFirstName;
        private Label lblLastName;
        private Label lblGPA;
        private Label lblProgram;
        private TextBox txtProgram;
        private Button btnShowAll;
        private Button btnFilterProgram;
        private Button btnFilterGPA;
        private Button btnSearch;
        private Button btnSortName;
        private Button btnSortGPA;
        private TextBox txtLINGQSearch;
        private NumericUpDown nudLINQGPA;
        private ComboBox cboLINQProgram;
        private Button btnLINQDisplay;
        private DataGridView dgvLINQStudents;
    }
}
